#include <stddef.h>
#include <kilolib.h>

message_t ready;

int waitingForInstruction = 0;

int instructionID = 0;
int instructionParam = 0;

int straightSpeedCalibrator = 1000; // Delay in milliseconds to go straight on 1cm
int turningSpeedCalibrator = 5000; // Delay in milliseconds to make 1 turn around


void setup() {
    // Wait to be called by the instructor
    waitingForInstruction = 1;

    ready.type = NORMAL;
    ready.crc = message_crc(&ready);
}

void loop() {
    if (waitingForInstruction) {
        // Waits for orders. Blink yellow
        delay(500);
        set_color(RGB(1,1,0));
        delay(500);
        set_color(RGB(0,0,0));
    }
    else {
        switch(instructionID) {
            case 1:
                // Rookie shows his war face
                set_color(RGB(0, 1, 1));
                delay(500);
                set_color(RGB(0,0,0));
                break;
            case 2:
                // Rookie runs x centimeters, then comes back
                for (int i = 0 ; i < 2 ; i++) {
                    spinup_motors();
              	    set_motors(kilo_straight_left, kilo_straight_right);
                    delay(instructionParam * straightSpeedCalibrator); // the multiplicator must be calibrated depending on the kilobot's speed
                    set_motors(kilo_turn_left, 0);
                    delay(turningSpeedCalibrator);
                    set_motors(0, 0);
                }
                break;
            case 3:
                // Rookie turns around on himself x times
                for (int i = 0 ; i < instructionParam ; i++) {
                    spinup_motors();
                    set_motors(kilo_turn_left, 0);
                    delay(turningSpeedCalibrator);
                    set_motors(0, 0);
                }
                break;
        }
        waitingForInstruction = 1;
        delay(2000);  // Waits two seconds before executing the next instruction
    }
}

void message_rx(message_t *msg, distance_measurement_t *dist) {
    // This function is called when the rookie says he is ready
    instructionID = msg->data[0];
    instructionParam = msg->data[1];
    waitingForInstruction = 0;
}

message_t* message_tx() {
	// Send a message if the rookie is ready. If not, sends nothing.
    if (waitingForInstruction) {
        return &ready;
    }
    return NULL;
}

int main() {
    // Initializes hardware
    kilo_init();

    // Registers the function to call when receiving a instruction
    kilo_message_rx = message_rx;

    // Registers the function to call when sending a message
    kilo_message_tx = message_tx;

    // Starts program
    kilo_start(setup, loop);

    return 0;
}
