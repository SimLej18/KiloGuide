#include <kilolib.h>

message_t instruction;
int instructionID;
int instructionParam;

// Define flags
int instructionGiven = 0;

void makeInstruction() {
    // Create a instruction to be given to the rookie
    instruction.type = NORMAL;
    instruction.data[0] = instructionID;
    instruction.data[1] = instructionParam;
    instruction.crc = message_crc(&instruction);
}

void generateInstruction() {
    // Gives an instruction to the rookie

    instructionID = (rand_hard() % 3) + 1;  // Instructions have a specific number, from 1 to 3

    switch (instructionID) {
        case 1:
            // Rookie must show his war face ! (Turn on his led)
            instructionParam = 0;
            break;

        case 2:
            // Rookie must run x centimeters, then come back.
            instructionParam = 3 + (rand_hard() % 8); // Cm to be runned, from 3 to 10
            break;

        case 3:
            // Rookie must turn around on himself x times.
            instructionParam = 1 + (rand_hard() % 3); // number of turns, from 1 to 3
            break;
    }
    makeInstruction();
}

void setup() {
}

void loop() {
    if (!instructionGiven) {
        // Gives an order. Blinks a specific color depending on the given order
        generateInstruction();

        switch (instructionID) {
            case 1:
                set_color(RGB(1,0, 0)); // Blinks red
                break;

            case 2:
                set_color(RGB(0, 1, 0)); // Blinks green
                break;

            case 3:
                set_color(RGB(0, 0, 1)); // Blinks green to
                break;
        }
        delay(500);
        set_color(RGB(0,0,0));
        instructionGiven = 1;
    }
    else {
        // Waits for the rookie. Blink yellow
        delay(500);
        set_color(RGB(1,1,0));
        delay(500);
        set_color(RGB(0,0,0));
    }
}

message_t* message_tx() {
    return &instruction;
}

void message_rx(message_t *msg, distance_measurement_t *dist) {
    // This function is called when the instruction has been successfully transmitted
    instructionGiven = 0;
}

int main() {
    // initialize hardware
    kilo_init();

    // Registers the function to call when sending a instruction
    kilo_message_tx = message_tx;

    // Registers the function to call when rookie says he is ready
    kilo_message_rx = message_rx;

    // start program
    kilo_start(setup, loop);

    return 0;
}
