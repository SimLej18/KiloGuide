#include <kilolib.h>

#define MAX_LEVEL 5
#define TIMEOUT 30

message_t message;

int level = MAX_LEVEL;
int timer = 0;

void setup() {
    message.type = NORMAL;
}

void loop() {
    // Update timer
    timer++;
    if (timer >= TIMEOUT && level < MAX_LEVEL) {
        level++;
        timer = 0;
    }

    // Set light
    switch (level) {
        case 1:
            set_color(RGB(0, 3, 0));
            delay(50);
            break;
        case 2:
            set_color(RGB(1, 3, 0));
            delay(50);
            break;
        case 3:
            set_color(RGB(3, 3, 0));
            delay(50);
            break;
        case 4:
            set_color(RGB(3, 1, 0));
            delay(50);
            break;
        case MAX_LEVEL:
            set_color(RGB(3, 0, 0));
            delay(50);
            break;
    }
}

void message_rx(message_t *m, distance_measurement_t *d) {
    if (m->data[0] < level-1) {
        // Change level
        level = m->data[0] + 1;
        timer = 0;
    }
    if (m->data[0] == level-1) {
        // Reset timer
        timer = 0;
    }
}

message_t* message_tx() {
    message.data[0] = level;
    message.crc = message_crc(&message);
    return &message;
}

int main() {
    // initialize hardware
    kilo_init();

    kilo_message_rx = message_rx;
    kilo_message_tx = message_tx;

    // start program
    kilo_start(setup, loop);

    return 0;
}
