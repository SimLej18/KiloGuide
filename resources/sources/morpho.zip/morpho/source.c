#include <kilolib.h>

message_t message;

int level = 0;  // 0 as this cell is the source

void setup() {
    // Set message content
    message.type = NORMAL;
    message.data[0] = level;
    message.crc = message_crc(&message);

    // Set light
    set_color(RGB(3, 3, 3));
}

void loop() {
    // Nothing to do
}

message_t* message_tx() {
    return &message;
}

int main() {
    // initialize hardware
    kilo_init();

    kilo_message_tx = message_tx;

    // start program
    kilo_start(setup, loop);

    return 0;
}
